/**
 * TIS Portal - Re-engineered Main Application Logic
 * Supports 12+ sections, Dark Mode, Global Search, and Notifications
 */

(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        // --- Core Elements ---
        const els = {
            sidebar: helpers.qs('#sidebar'),
            toggleBtn: helpers.qs('#toggle-sidebar'),
            dynamicContent: helpers.qs('#dynamic-content'),
            skeleton: helpers.qs('#skeleton-loader'),
            breadcrumb: helpers.qs('#breadcrumb-active'),
            navLinks: helpers.qsa('.nav-link'),
            themeToggle: helpers.qs('#theme-toggle'),
            globalSearch: helpers.qs('#global-search'),
            emergencyBanner: helpers.qs('#emergency-banner'),
            closeEmergency: helpers.qs('#close-emergency')
        };

        // --- App State ---
        const state = {
            currentSection: '',
            isDark: storage.get('tis_theme') === 'dark',
            isSidebarCollapsed: storage.get('tis_sidebar') === 'collapsed'
        };

        // --- Section Specific Features ---

        function initQuiz() {
            const container = helpers.qs('#quiz-container');
            const questions = [
                { q: "다음 중 피싱 메일의 특징으로 적절하지 않은 것은?", a: ["보낸 사람 주소가 공식 도메인과 다름", "긴급한 작업(비밀번호 변경 등)을 요구함", "맞춤형 인사말 대신 '고객님' 등 모호한 표현 사용", "보안을 위해 첨부파일 실행을 권고함"], correct: 3 },
                { q: "공공장소에서 Wi-Fi 사용 시 가장 권장되는 행위는?", a: ["금융 거래나 쇼핑몰 접속", "개인용 VPN 서비스 사용", "모든 알림 허용", "블루투스 기기 상시 연결"], correct: 1 },
                { q: "패스워드 설정 시 보안성이 가장 높은 조합은?", a: ["본인 생일과 전화번호", "연속된 숫자 (123456)", "특수문자 포함 10자 이상의 복합 문자", "사전에 있는 흔한 단어"], correct: 2 }
            ];

            let step = 0;
            let score = 0;

            const renderStep = () => {
                if (step >= questions.length) {
                    container.innerHTML = `
                        <div class="p-10 text-center">
                            <i class="fas fa-trophy text-6xl text-yellow-500 mb-6"></i>
                            <h3 class="text-2xl font-black mb-2 dark:text-gray-100">퀴즈 결과: ${score}/${questions.length}</h3>
                            <p class="text-gray-500 text-sm mb-8 font-bold">참여해 주셔서 감사합니다! <br> 보안 지수가 +10 포인트 상승했습니다.</p>
                            <button onclick="app.loadSection('security_center')" class="px-8 py-3 bg-[#1e3a8a] text-white rounded-xl font-bold transition transform active:scale-95">교육 센터로 돌아가기</button>
                        </div>
                    `;
                    return;
                }

                const item = questions[step];
                container.innerHTML = `
                    <div class="p-8 border-b border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50">
                        <div class="flex justify-between items-center mb-4">
                            <span class="text-[10px] font-black text-blue-500 uppercase">Question ${step + 1}/${questions.length}</span>
                            <div class="w-32 bg-gray-200 dark:bg-gray-700 h-1.5 rounded-full overflow-hidden">
                                <div class="bg-blue-500 h-full transition-all duration-500" style="width: ${(step + 1) / questions.length * 100}%"></div>
                            </div>
                        </div>
                        <h4 class="text-lg font-black dark:text-gray-100">${item.q}</h4>
                    </div>
                    <div class="p-8 space-y-3">
                        ${item.a.map((ans, i) => `
                            <button class="quiz-ans w-full p-4 text-left bg-white dark:bg-gray-900 border-2 border-gray-100 dark:border-gray-700 rounded-2xl hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all font-bold text-sm dark:text-gray-300" data-idx="${i}">
                                ${i + 1}. ${ans}
                            </button>
                        `).join('')}
                    </div>
                `;

                helpers.qsa('.quiz-ans', container).forEach(btn => {
                    btn.onclick = () => {
                        const idx = parseInt(btn.getAttribute('data-idx'));
                        if (idx === item.correct) {
                            score++;
                            notifications.show('정답입니다!', 'success', 1500);
                        } else {
                            notifications.show('오답입니다.', 'error', 1500);
                        }
                        step++;
                        renderStep();
                    };
                });
            };

            renderStep();
        }
        // --- Section Definitions ---
        const sections = {
            home: {
                title: '대시보드',
                render: () => `
                    <div class="section-animate">
                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                            <div class="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                                <div class="flex justify-between items-center mb-4">
                                    <h4 class="font-bold text-gray-500 dark:text-gray-400 text-xs">최근 보안 사고</h4>
                                    <span class="p-2 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-lg text-xs"><i class="fas fa-check"></i></span>
                                </div>
                                <p class="text-3xl font-black mb-1">0 <span class="text-sm font-bold text-gray-400">건</span></p>
                                <p class="text-[10px] text-green-500 font-bold"><i class="fas fa-caret-down"></i> 지난주 대비 100% 감소</p>
                            </div>
                            <div class="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                                <div class="flex justify-between items-center mb-4">
                                    <h4 class="font-bold text-gray-500 dark:text-gray-400 text-xs">오늘의 위협 차단</h4>
                                    <span class="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-lg text-xs"><i class="fas fa-shield"></i></span>
                                </div>
                                <p class="text-3xl font-black mb-1">1,284 <span class="text-sm font-bold text-gray-400">건</span></p>
                                <p class="text-[10px] text-blue-500 font-bold"><i class="fas fa-caret-up"></i> 실시간 모니터링 중</p>
                            </div>
                            <div class="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                                <div class="flex justify-between items-center mb-4">
                                    <h4 class="font-bold text-gray-500 dark:text-gray-400 text-xs">교육 이수율</h4>
                                    <span class="p-2 bg-purple-100 dark:bg-purple-900/30 text-purple-600 rounded-lg text-xs"><i class="fas fa-user-graduate"></i></span>
                                </div>
                                <p class="text-3xl font-black mb-1">94 <span class="text-sm font-bold text-gray-400">%</span></p>
                                <div class="w-full bg-gray-100 dark:bg-gray-700 h-1.5 rounded-full mt-2">
                                    <div class="bg-purple-500 h-full rounded-full" style="width: 94%"></div>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
                            <h3 class="text-lg font-bold mb-6">최근 보안 공지사항</h3>
                            <div class="space-y-4">
                                ${[1, 2, 3].map(i => `
                                    <div class="flex items-center gap-4 p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 rounded-xl transition cursor-pointer border border-transparent hover:border-gray-100 dark:hover:border-gray-600">
                                        <div class="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-900/20 flex flex-col items-center justify-center text-[#1e3a8a] dark:text-blue-400 shrink-0">
                                            <span class="text-xs font-black">JAN</span>
                                            <span class="text-sm font-black">2${i}</span>
                                        </div>
                                        <div class="flex-grow">
                                            <div class="flex items-center gap-2 mb-1">
                                                <span class="px-2 py-0.5 bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-300 text-[10px] font-bold rounded">정책변경</span>
                                                <span class="text-[10px] text-gray-400 font-bold">14:20 PM</span>
                                            </div>
                                            <h4 class="text-sm font-bold text-gray-800 dark:text-gray-200">사내 시스템 패스워드 고도화 정책 안내</h4>
                                        </div>
                                        <i class="fas fa-chevron-right text-gray-300 text-xs"></i>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                `
            },
            security_center: {
                title: '보안 교육 센터',
                render: () => `
                    <div class="section-animate max-w-5xl mx-auto">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                             <div class="bg-gradient-to-br from-[#1e3a8a] to-blue-600 p-8 rounded-3xl text-white shadow-xl relative overflow-hidden">
                                <div class="absolute -right-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full"></div>
                                <h3 class="text-2xl font-black mb-2">나의 교육 현황</h3>
                                <p class="text-blue-100 text-sm mb-6">2026년 상반기 필수 교육 4개 중 3개를 완료했습니다.</p>
                                <div class="flex items-end justify-between mb-2">
                                    <span class="text-3xl font-black">75%</span>
                                    <span class="text-xs font-bold text-blue-200">Good Job!</span>
                                </div>
                                <div class="w-full bg-white/20 h-3 rounded-full overflow-hidden">
                                    <div class="bg-white h-full" style="width: 75%"></div>
                                </div>
                             </div>
                             <div class="bg-white dark:bg-gray-800 p-8 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm flex flex-col justify-center">
                                <div class="flex items-center gap-4 mb-4">
                                    <div class="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-900/20 text-red-600 flex items-center justify-center text-xl">
                                        <i class="fas fa-fish"></i>
                                    </div>
                                    <div>
                                        <h4 class="font-bold dark:text-gray-100">피싱 메일 시뮬레이션</h4>
                                        <p class="text-xs text-gray-500">실전 대응 능력을 테스트하세요.</p>
                                    </div>
                                </div>
                                <button onclick="notifications.show('시뮬레이션이 곧 시작됩니다. 메일함을 확인하세요.', 'info')" class="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold transition transform active:scale-95 shadow-lg shadow-red-500/20">테스트 시작하기</button>
                             </div>
                        </div>

                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            <div class="lg:col-span-2 space-y-6">
                                <div class="flex items-center justify-between">
                                    <h3 class="text-lg font-black flex items-center gap-2 dark:text-gray-100"><i class="fas fa-book-open text-blue-500"></i> 추천 교육 과정</h3>
                                    <button class="text-[10px] font-bold text-blue-500 hover:underline">모든 과정 보기</button>
                                </div>
                                ${[
                        { title: '랜섬웨어 예방과 대응 가이드', type: 'VIDEO', time: '15분', status: '진행 중', color: 'blue' },
                        { title: '개인정보 취급자 필수 수칙 (2026)', type: 'PDF', time: '20분', status: '미시작', color: 'red' },
                        { title: '클라우드 보안 설정 베스트 프랙티스', type: 'VIDEO', time: '40분', status: '미시작', color: 'blue' }
                    ].map(c => `
                                    <div class="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 flex items-center gap-4 hover:shadow-md transition cursor-pointer group">
                                        <div class="w-14 h-14 rounded-xl bg-gray-50 dark:bg-gray-900 flex items-center justify-center text-gray-400 group-hover:scale-110 transition-transform">
                                            <i class="fas ${c.type === 'VIDEO' ? 'fa-play-circle text-2xl text-blue-500' : 'fa-file-pdf text-2xl text-red-500'}"></i>
                                        </div>
                                        <div class="flex-grow">
                                            <h4 class="font-bold text-sm mb-1 dark:text-gray-200">${c.title}</h4>
                                            <div class="flex items-center gap-3 text-[10px] font-bold text-gray-400">
                                                <span><i class="far fa-clock mr-1"></i>${c.time}</span>
                                                <span class="uppercase">${c.type}</span>
                                            </div>
                                        </div>
                                        <span class="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-[10px] font-black rounded-lg dark:text-gray-300">${c.status}</span>
                                    </div>
                                `).join('')}
                            </div>
                            <div class="bg-[#1e3a8a] rounded-3xl p-6 text-white text-center flex flex-col items-center justify-center shadow-2xl relative overflow-hidden">
                                <div class="absolute top-0 left-0 w-full h-full bg-blue-600/20 blur-3xl -z-10"></div>
                                <i class="fas fa-lightbulb text-4xl mb-4 text-yellow-400 animate-bounce"></i>
                                <h3 class="text-xl font-black mb-2">오늘의 보안 퀴즈</h3>
                                <p class="text-blue-200 text-xs mb-6 leading-relaxed">매일 새로운 퀴즈로 지식을 체크하고<br>활동 배지를 획득하세요!</p>
                                <button onclick="app.loadSection('quiz')" class="w-full py-4 bg-white text-[#1e3a8a] rounded-2xl font-black hover:bg-blue-50 transition shadow-xl transform hover:-translate-y-1">지금 바로 시작</button>
                            </div>
                        </div>
                    </div>
                `
            },
            quiz: {
                title: '보안 퀴즈',
                render: () => `
                    <div class="section-animate max-w-2xl mx-auto">
                        <div id="quiz-container" class="bg-white dark:bg-gray-800 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-700 overflow-hidden">
                            <!-- Quiz content will be injected by afterRender -->
                            <div class="p-20 text-center"><div class="loading-spinner"></div></div>
                        </div>
                    </div>
                `,
                afterRender: () => app.initQuiz()
            },
            incident: {
                title: '인시던트 신고',
                render: () => `
                    <div class="section-animate max-w-4xl mx-auto">
                        <div class="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
                            <div class="p-8 border-b border-gray-100 dark:border-gray-700">
                                <h3 class="text-xl font-black mb-2">보안 위협 / 인시던트 제보</h3>
                                <p class="text-gray-500 text-xs">의심스러운 이메일, 시스템 이상 징후, 개인정보 유출 의심 사례를 즉시 신고해 주세요.</p>
                            </div>
                            <form id="incident-form" class="p-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div class="space-y-2">
                                    <label class="text-xs font-black text-gray-500 uppercase">사고 유형</label>
                                    <select required class="w-full p-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none">
                                        <option value="">유형을 선택하세요</option>
                                        <option>피싱/스팸 메일</option>
                                        <option>악성코드/바이러스 감염</option>
                                        <option>비인가 접근/해킹 의심</option>
                                        <option>개인정보/기밀 유출</option>
                                        <option>자산 분실/도난</option>
                                    </select>
                                </div>
                                <div class="space-y-2">
                                    <label class="text-xs font-black text-gray-500 uppercase">긴급도</label>
                                    <div class="flex gap-2">
                                        <label class="flex-1 cursor-pointer">
                                            <input type="radio" name="priority" value="low" class="hidden peer">
                                            <div class="text-center py-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 peer-checked:border-green-500 peer-checked:bg-green-50 dark:peer-checked:bg-green-900/20 text-[10px] font-black transition">LOW</div>
                                        </label>
                                        <label class="flex-1 cursor-pointer">
                                            <input type="radio" name="priority" value="medium" checked class="hidden peer">
                                            <div class="text-center py-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 peer-checked:border-yellow-500 peer-checked:bg-yellow-50 dark:peer-checked:bg-yellow-900/20 text-[10px] font-black transition">MEDIUM</div>
                                        </label>
                                        <label class="flex-1 cursor-pointer">
                                            <input type="radio" name="priority" value="high" class="hidden peer">
                                            <div class="text-center py-3 rounded-xl border-2 border-gray-100 dark:border-gray-700 peer-checked:border-red-500 peer-checked:bg-red-50 dark:peer-checked:bg-red-900/20 text-[10px] font-black transition">HIGH</div>
                                        </label>
                                    </div>
                                </div>
                                <div class="md:col-span-2 space-y-2">
                                    <label class="text-xs font-black text-gray-500 uppercase">상세 내용</label>
                                    <textarea required placeholder="사건 발생 일시, 증상, 대상 시스템 등을 상세히 기술해 주세요." class="w-full p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-2xl h-40 focus:ring-2 focus:ring-blue-500 outline-none"></textarea>
                                </div>
                                <div class="md:col-span-2 space-y-2">
                                    <label class="text-xs font-black text-gray-500 uppercase">첨부 파일 (캡처 등)</label>
                                    <div class="border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-2xl p-8 text-center hover:bg-gray-50 dark:hover:bg-gray-900 transition cursor-pointer">
                                        <i class="fas fa-cloud-upload-alt text-3xl text-gray-300 mb-2"></i>
                                        <p class="text-xs text-gray-400">파일을 드래그하거나 클릭하여 업로드하세요 (최대 10MB)</p>
                                    </div>
                                </div>
                                <div class="md:col-span-2 pt-4">
                                    <button type="button" onclick="notifications.show('신고가 접수되었습니다. 담당자가 확인 후 연락드리겠습니다.', 'success')" class="w-full py-4 bg-[#1e3a8a] text-white rounded-2xl font-black text-lg hover:shadow-2xl transition transform active:scale-95">리포트 제출 완료</button>
                                </div>
                            </form>
                        </div>

                        <!-- Emergency Contacts -->
                        <div class="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="bg-blue-600 p-6 rounded-3xl text-white flex items-center gap-4">
                                <div class="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center text-xl"><i class="fas fa-phone"></i></div>
                                <div>
                                    <p class="text-[10px] font-bold text-blue-200 uppercase">24/7 보안팀 긴급 핫라인</p>
                                    <p class="text-lg font-black">02-1234-5678</p>
                                </div>
                            </div>
                            <div class="bg-gray-800 p-6 rounded-3xl text-white flex items-center gap-4">
                                <div class="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-xl"><i class="fas fa-envelope"></i></div>
                                <div>
                                    <p class="text-[10px] font-bold text-gray-400 uppercase">보안센터 이메일</p>
                                    <p class="text-lg font-black">tis-sos@twayair.com</p>
                                </div>
                            </div>
                        </div>
                    </div>
                `
            },
            system_status: {
                title: '시스템 상태 대시보드',
                render: () => `
                    <div class="section-animate">
                        <div class="mb-8 flex justify-between items-end">
                            <div>
                                <h3 class="text-2xl font-black mb-1">인프라 실시간 모니터링</h3>
                                <p class="text-gray-500 text-xs">최종 업데이트: <span id="last-update">방금 전</span></p>
                            </div>
                            <div class="flex items-center gap-2 px-4 py-2 bg-green-100 text-green-700 rounded-full text-[10px] font-black animate-pulse">
                                <div class="w-2 h-2 bg-green-500 rounded-full"></div> 전 시스템 정상 운영 중
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                            ${[
                        { name: 'WAF', status: 'Active', color: 'green', load: '12%' },
                        { name: 'VPN Gateway', status: 'Active', color: 'green', load: '45%' },
                        { name: 'IPS/IDS', status: 'In Check', color: 'yellow', load: 'N/A' },
                        { name: 'DLP Server', status: 'Active', color: 'green', load: '23%' }
                    ].map(s => `
                                <div class="bg-white dark:bg-gray-800 p-6 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm relative overflow-hidden group">
                                    <div class="absolute -right-4 -top-4 w-20 h-20 bg-${s.color}-50 dark:bg-${s.color}-900/10 rounded-full transition-transform group-hover:scale-150"></div>
                                    <div class="relative z-10">
                                        <h4 class="font-black text-gray-400 text-[10px] uppercase mb-4">${s.name}</h4>
                                        <div class="flex items-end justify-between">
                                            <span class="text-sm font-black text-gray-800 dark:text-gray-200">${s.status}</span>
                                            <span class="text-xs font-bold text-${s.color}-500">${s.load}</span>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>

                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            <div class="lg:col-span-2 bg-white dark:bg-gray-800 p-8 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm">
                                <h4 class="font-black text-sm mb-6">최근 24시간 위협 차단 트렌드</h4>
                                <canvas id="threat-chart" class="h-64"></canvas>
                            </div>
                            <div class="bg-white dark:bg-gray-800 p-8 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm">
                                <h4 class="font-black text-sm mb-6">점검 일정</h4>
                                <div class="space-y-4">
                                    <div class="p-4 bg-orange-50 dark:bg-orange-900/20 border-l-4 border-orange-500 rounded-r-xl">
                                        <p class="text-[10px] font-black text-orange-600 dark:text-orange-400 uppercase">Upcoming</p>
                                        <h5 class="text-sm font-bold mt-1">방화벽 OS 정기 패치</h5>
                                        <p class="text-[10px] text-gray-500 font-bold mt-1">2026.02.01 02:00 ~ 04:00</p>
                                    </div>
                                    <div class="p-4 bg-gray-50 dark:bg-gray-900 border-l-4 border-gray-300 dark:border-gray-700 rounded-r-xl">
                                        <h5 class="text-sm font-bold">NAC DB 최적화 작업</h5>
                                        <p class="text-[10px] text-gray-500 font-bold mt-1">2026.02.05 23:00 ~ 01:00</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `,
                afterRender: () => {
                    const ctx = document.getElementById('threat-chart').getContext('2d');
                    new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00'],
                            datasets: [{
                                label: 'Threats Blocked',
                                data: [120, 80, 450, 320, 210, 540],
                                borderColor: '#1e3a8a',
                                tension: 0.4,
                                fill: true,
                                backgroundColor: 'rgba(30, 58, 138, 0.1)'
                            }]
                        },
                        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
                    });
                }
            },
            pledge: {
                title: '보안 서약서',
                render: () => `
                    <div class="section-animate max-w-4xl mx-auto">
                        <div class="bg-white dark:bg-gray-800 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-700 p-10">
                            <div class="text-center mb-12">
                                <h3 class="text-3xl font-black text-[#1e3a8a] dark:text-blue-400 mb-2">Information Security Pledge</h3>
                                <p class="text-gray-400 text-sm font-bold uppercase tracking-widest italic">Confidentiality Agreement</p>
                            </div>
                            
                            <div class="info-grid mt-8 mb-10">
                                <div class="info-field">
                                    <label>Full Name</label>
                                    <input type="text" placeholder="Enter your name">
                                </div>
                                <div class="info-field">
                                    <label>Department</label>
                                    <input type="text" placeholder="Enter department">
                                </div>
                                <div class="info-field">
                                    <label>Employee ID</label>
                                    <input type="text" placeholder="Enter ID">
                                </div>
                                <div class="info-field">
                                    <label>Date</label>
                                    <input type="date" value="${helpers.formatDate(new Date())}">
                                </div>
                            </div>

                            <div class="space-y-4 mb-10">
                                ${[
                        'I will strictly adhere to the company\'s information security policies.',
                        'I will not disclose any confidential information to third parties.',
                        'I will use the company\'s assets only for authorized business purposes.',
                        'I will report any security incidents to the TIS department immediately.',
                        'I recognize that violations may result in disciplinary action.'
                    ].map((text, i) => `
                                    <div class="flex gap-4 p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-700">
                                        <span class="text-blue-500 font-black text-lg">0${i + 1}</span>
                                        <p class="text-sm font-bold text-gray-700 dark:text-gray-300">${text}</p>
                                    </div>
                                `).join('')}
                            </div>

                            <div class="mb-10 p-6 bg-blue-50/30 dark:bg-blue-900/10 rounded-3xl border border-blue-100 dark:border-blue-900/50">
                                <div class="flex justify-between items-end mb-4">
                                    <label class="text-[10px] font-black text-blue-500 uppercase tracking-widest">Digital Signature Required</label>
                                    <button id="clear-signature" class="text-[10px] text-red-500 font-bold hover:underline">Clear Canvas</button>
                                </div>
                                <canvas id="signature-pad" class="w-full h-48 bg-white dark:bg-gray-900 rounded-2xl shadow-inner border border-gray-100 dark:border-gray-700"></canvas>
                            </div>

                            <label class="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl cursor-pointer mb-10 hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                                <input type="checkbox" id="agree-check" class="w-6 h-6 rounded-lg text-blue-600 focus:ring-blue-500 border-gray-300 cursor-pointer">
                                <span class="text-sm font-black text-gray-700 dark:text-gray-300">I have read and agree to all terms of this pledge.</span>
                            </label>

                            <button onclick="notifications.show('서약서가 정상적으로 제출되었습니다.', 'success')" class="w-full py-5 bg-[#1e3a8a] text-white rounded-2xl font-black text-xl hover:shadow-2xl transition transform active:scale-98">Sign and Submit</button>
                        </div>
                    </div>
                `,
                afterRender: () => initSignaturePad()
            },
            // Other placeholders for now...
            assets: {
                title: '자산 관리',
                render: () => `
                    <div class="section-animate max-w-5xl mx-auto">
                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                            <div class="lg:col-span-2 bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
                                <div class="p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center">
                                    <h3 class="font-black">내 할당 자산 목록</h3>
                                    <span class="text-[10px] font-bold text-gray-400">총 3개 장비</span>
                                </div>
                                <div class="overflow-x-auto">
                                    <table class="w-full text-left">
                                        <thead class="bg-gray-50 dark:bg-gray-900/50 text-[10px] uppercase font-black text-gray-400">
                                            <tr>
                                                <th class="px-6 py-4">아이템</th>
                                                <th class="px-6 py-4">시리얼 번호</th>
                                                <th class="px-6 py-4">할당일</th>
                                                <th class="px-6 py-4">상태</th>
                                            </tr>
                                        </thead>
                                        <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                                            ${[
                        { name: 'MacBook Pro 16"', sn: 'SN-TWAY-9821', date: '2024.12.10', status: '정상', color: 'green' },
                        { name: 'Dell 27" Monitor', sn: 'SN-MON-4432', date: '2024.12.10', status: '정상', color: 'green' },
                        { name: 'Yubikey 5C', sn: 'SN-YUBI-0012', date: '2025.01.05', status: '정상', color: 'green' }
                    ].map(a => `
                                                <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition text-sm">
                                                    <td class="px-6 py-4 font-bold dark:text-gray-200">${a.name}</td>
                                                    <td class="px-6 py-4 text-xs font-mono text-gray-500">${a.sn}</td>
                                                    <td class="px-6 py-4 text-xs text-gray-500">${a.date}</td>
                                                    <td class="px-6 py-4"><span class="px-2 py-0.5 bg-${a.color}-100 dark:bg-${a.color}-900/30 text-${a.color}-600 text-[10px] font-black rounded">${a.status}</span></td>
                                                </tr>
                                            `).join('')}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
                                <h3 class="font-black mb-6">자산 신청 / 교체</h3>
                                <form class="space-y-4">
                                    <div class="space-y-1">
                                        <label class="text-[10px] font-black text-gray-400 uppercase">장비 종류</label>
                                        <select class="w-full p-3 bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500">
                                            <option>노트북 (Win/Mac)</option>
                                            <option>모니터</option>
                                            <option>보안 토큰 (OTPs)</option>
                                            <option>기타 주변기기</option>
                                        </select>
                                    </div>
                                    <div class="space-y-1">
                                        <label class="text-[10px] font-black text-gray-400 uppercase">사유</label>
                                        <textarea placeholder="신청 사유를 입력하세요." class="w-full p-3 bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-700 rounded-xl text-sm h-24 outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                                    </div>
                                    <button type="button" onclick="notifications.show('자산 신청이 접수되었습니다.', 'success')" class="w-full py-3 bg-[#1e3a8a] text-white rounded-xl font-black text-sm hover:shadow-lg transition active:scale-95">신청하기</button>
                                </form>
                            </div>
                        </div>
                    </div>
                `
            },
            access: {
                title: '권한 관리',
                render: () => `
                    <div class="section-animate max-w-5xl mx-auto">
                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            <div class="lg:col-span-2 space-y-6">
                                <div class="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
                                    <div class="p-6 border-b border-gray-100 dark:border-gray-700">
                                        <h3 class="font-black">보유 시스템 권한</h3>
                                    </div>
                                    <div class="divide-y divide-gray-50 dark:divide-gray-700">
                                        ${[
                        { sys: 'ERP 시스템', level: 'ReadOnly', expiry: '무기한', status: 'Active' },
                        { sys: 'WAF 관리 콘솔', level: 'Admin', expiry: '2026.12.31', status: 'Expiring Soon' },
                        { sys: 'AWS Production', level: 'Developer', expiry: '2026.06.30', status: 'Active' }
                    ].map(r => `
                                            <div class="p-5 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700/20 transition">
                                                <div class="flex items-center gap-4">
                                                    <div class="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-600"><i class="fas fa-server"></i></div>
                                                    <div>
                                                        <h4 class="font-bold text-sm dark:text-gray-200">${r.sys}</h4>
                                                        <p class="text-[10px] text-gray-400 font-bold">${r.level} 레벨 | 만료: ${r.expiry}</p>
                                                    </div>
                                                </div>
                                                <span class="px-2 py-1 ${r.status === 'Active' ? 'bg-green-100 text-green-600' : 'bg-orange-100 text-orange-600'} text-[10px] font-black rounded">${r.status}</span>
                                            </div>
                                        `).join('')}
                                    </div>
                                </div>
                            </div>
                            <div class="bg-gray-900 border border-gray-800 rounded-3xl p-8 text-white relative overflow-hidden">
                                <div class="relative z-10 text-center">
                                    <i class="fas fa-key text-4xl mb-4 text-blue-400"></i>
                                    <h3 class="text-xl font-black mb-4">권한 신청 / 연장</h3>
                                    <p class="text-xs text-gray-400 mb-8 leading-relaxed">업무 수행에 필요한 권한을 신청하거나<br>만료 예정인 권한을 연장하세요.</p>
                                    <button onclick="notifications.show('권한 신청 폼이 열렸습니다.', 'info')" class="w-full py-4 bg-blue-600 hover:bg-blue-500 rounded-2xl font-black text-sm transition shadow-2xl transform active:scale-95">신규 권한 신청</button>
                                </div>
                                <div class="absolute -left-10 -bottom-10 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl"></div>
                            </div>
                        </div>
                    </div>
                `
            },
            policy: { title: '보안 규정', render: () => `<div class="p-20 text-center"><i class="fas fa-file-shield text-6xl text-gray-200 mb-6"></i><h3 class="text-2xl font-bold">보안 규정 섹션 준비 중...</h3></div>` },
            checklist: {
                title: '보안 체크리스트',
                render: () => `
                    <div class="section-animate max-w-4xl mx-auto">
                        <div class="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
                            <div class="p-8 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center">
                                <div>
                                    <h3 class="text-xl font-black mb-1">데일리 보안 점검</h3>
                                    <p class="text-xs text-gray-500">오늘의 보안 필수 수칙을 점검하세요.</p>
                                </div>
                                <div class="text-right">
                                    <span id="check-percent" class="text-2xl font-black text-blue-600">0%</span>
                                    <div class="w-32 bg-gray-100 dark:bg-gray-700 h-2 rounded-full mt-1 overflow-hidden">
                                        <div id="check-bar" class="bg-blue-500 h-full transition-all duration-500" style="width: 0%"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="p-8 space-y-4" id="checklist-items">
                                ${[
                        '자리를 비울 때 화면 잠금 (Win+L) 하였는가?',
                        '중요 문서를 책상 위에 방치하지 않았는가?',
                        '개인형 저장매체(USB 등)를 무단 사용하지 않았는가?',
                        '출처가 불분명한 이메일의 링크를 클릭하지 않았는가?',
                        '공식 승인된 공유 폴더만 사용 중인가?'
                    ].map((item, i) => `
                                    <label class="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl cursor-pointer hover:bg-white dark:hover:bg-gray-750 transition border border-transparent hover:border-gray-100 dark:hover:border-gray-700">
                                        <input type="checkbox" class="tis-check w-6 h-6 rounded-lg border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500" data-idx="${i}">
                                        <span class="text-sm font-bold text-gray-700 dark:text-gray-300">${item}</span>
                                    </label>
                                `).join('')}
                            </div>
                            <div class="p-8 bg-gray-50 dark:bg-gray-900/50 flex justify-between items-center">
                                <p class="text-[10px] text-gray-400 font-bold italic">* 점검 결과는 브라우저에 자동 저장됩니다.</p>
                                <button onclick="notifications.show('체크리스트가 PDF로 저장되었습니다.', 'success')" class="px-6 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-black shadow-sm hover:shadow-md transition"><i class="fas fa-file-pdf mr-2"></i>PDF 다운로드</button>
                            </div>
                        </div>
                    </div>
                `,
                afterRender: () => app.initChecklist()
            },
            reports: {
                title: '통계 리포트',
                render: () => `
                    <div class="section-animate max-w-5xl mx-auto">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                            <div class="bg-white dark:bg-gray-800 p-8 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm">
                                <h4 class="font-black text-sm mb-6 uppercase text-gray-400">월간 보안 트렌드</h4>
                                <canvas id="trend-chart" class="h-64"></canvas>
                            </div>
                            <div class="bg-white dark:bg-gray-800 p-8 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm">
                                <h4 class="font-black text-sm mb-6 uppercase text-gray-400">부서별 보안 준수율</h4>
                                <canvas id="dept-chart" class="h-64"></canvas>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            ${[
                        { label: '취약점 발견', val: '42', color: 'blue' },
                        { label: '해결 완료', val: '38', color: 'green' },
                        { label: '조치 중', val: '4', color: 'orange' }
                    ].map(c => `
                                <div class="bg-white dark:bg-gray-800 p-6 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm text-center">
                                    <p class="text-[10px] font-black text-gray-400 uppercase mb-2">${c.label}</p>
                                    <p class="text-4xl font-black text-${c.color}-500">${c.val}</p>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `,
                afterRender: () => app.initReports()
            },
            policy: {
                title: '보안 규정',
                render: () => `
                    <div class="section-animate max-w-5xl mx-auto">
                        <div class="flex items-center justify-between mb-8">
                            <h3 class="text-2xl font-black dark:text-gray-100">전사 보안 규정 및 가이드</h3>
                            <div class="flex gap-2">
                                <button class="px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-bold shadow-sm">최근 개정순</button>
                                <button class="px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-bold shadow-sm text-blue-500">중요도순</button>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            ${[
                        { title: '정보자산 관리 지침', version: 'v2.4', date: '2025.12.01', tag: '필독' },
                        { title: '패스워드 설정 및 운영 정책', version: 'v3.1', date: '2026.01.10', tag: '업데이트' },
                        { title: '재택근무 보안 가이드라인', version: 'v1.8', date: '2025.05.20', tag: '권고' },
                        { title: '클라우드 서비스 이용 정책', version: 'v2.0', date: '2025.11.15', tag: '필독' },
                        { title: '개인정보 보호 내부 관리 계획', version: 'v4.2', date: '2026.01.01', tag: '중요' },
                        { title: '물리 보안 및 출입 통제 규정', version: 'v1.5', date: '2024.08.30', tag: '정지' }
                    ].map(p => `
                                <div class="bg-white dark:bg-gray-800 p-6 rounded-3xl border border-gray-100 dark:border-gray-700 hover:shadow-xl transition-all group cursor-pointer">
                                    <div class="flex justify-between items-start mb-4">
                                        <div class="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-600 transition-colors group-hover:bg-blue-600 group-hover:text-white"><i class="fas fa-file-invoice"></i></div>
                                        <span class="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-[9px] font-black rounded uppercase dark:text-gray-400">${p.tag}</span>
                                    </div>
                                    <h4 class="font-bold text-sm mb-1 dark:text-gray-100">${p.title}</h4>
                                    <p class="text-[10px] text-gray-400 font-bold">버전: ${p.version} | 개정일: ${p.date}</p>
                                    <div class="mt-6 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button class="flex-1 py-2 bg-gray-50 dark:bg-gray-700 rounded-lg text-[9px] font-black uppercase"><i class="fas fa-eye mr-1"></i> View</button>
                                        <button class="flex-1 py-2 bg-gray-50 dark:bg-gray-700 rounded-lg text-[9px] font-black uppercase"><i class="fas fa-download mr-1"></i> Down</button>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `
            },
            process: {
                title: '업무 프로세스',
                render: () => `
                    <div class="section-animate max-w-4xl mx-auto">
                        <div class="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 p-10">
                            <h3 class="text-xl font-black mb-10 text-center uppercase tracking-widest text-gray-400">Security Workflow</h3>
                            <div class="relative border-l-4 border-blue-100 dark:border-blue-900/50 ml-6 space-y-12">
                                ${[
                        { step: '01', title: '보안성 검토 요청', desc: '신규 시스템 도입 또는 사내 서비스 구축 시 보안성 검토를 선행합니다.', icon: 'fa-paper-plane' },
                        { step: '02', title: '취약점 진단 및 조치', desc: '보안팀에서 자동/수동 진단을 수행하며, 발견된 취약점은 해당 부서에서 조치합니다.', icon: 'fa-code-branch' },
                        { step: '03', title: '보안 요건 검증', desc: '조치 사항이 완벽히 이행되었는지 최종 검증 과정을 거칩니다.', icon: 'fa-user-check' },
                        { step: '04', title: '시스템 오픈 승인', desc: '검증된 시스템에 대해 최종 보안 승인 후 서비스를 오픈합니다.', icon: 'fa-rocket' }
                    ].map(s => `
                                    <div class="relative pl-10 group">
                                        <div class="absolute -left-3.5 top-0 w-6 h-6 bg-white dark:bg-gray-800 rounded-full border-4 border-blue-500 group-hover:scale-125 transition-transform z-10"></div>
                                        <div class="flex items-start gap-6">
                                            <div class="w-14 h-14 rounded-2xl bg-blue-50 dark:bg-blue-900/20 text-[#1e3a8a] dark:text-blue-400 flex items-center justify-center text-xl shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-all"><i class="fas ${s.icon}"></i></div>
                                            <div>
                                                <span class="text-[10px] font-black text-blue-500 dark:text-blue-400 uppercase tracking-tighter">Step ${s.step}</span>
                                                <h4 class="text-lg font-black dark:text-gray-100 mb-1">${s.title}</h4>
                                                <p class="text-sm text-gray-500 leading-relaxed font-bold">${s.desc}</p>
                                            </div>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                `
            },
            faq: {
                title: 'FAQ',
                render: () => `
                    <div class="section-animate max-w-4xl mx-auto">
                        <div class="mb-10 text-center">
                            <h3 class="text-3xl font-black mb-4 dark:text-gray-100">자주 묻는 보안 질문</h3>
                            <div class="relative max-w-xl mx-auto">
                                <i class="fas fa-search absolute left-5 top-1/2 -translate-y-1/2 text-gray-400"></i>
                                <input type="text" placeholder="질문을 검색해 보세요..." class="w-full pl-14 pr-6 py-4 bg-white dark:bg-gray-800 rounded-2xl shadow-sm border-none focus:ring-2 focus:ring-blue-500 outline-none text-sm">
                            </div>
                        </div>
                        <div class="space-y-4">
                            ${[
                        { q: 'VPN 접속 시 2차 인증(OTP)이 안 와요.', a: '모바일 앱 "TIS OTP"가 최신 버전인지 확인하고, 앱 내에서 계정 재동기화를 진행해 주세요. 해결되지 않으면 내선 1234로 연락 바랍니다.' },
                        { q: '사외에서 인트라넷을 사용하고 싶어요.', a: '개인 PC 또는 노트북에서 VPN 설치가 필요합니다. [자산/권한 신청] 메뉴에서 VPN 접속 권한을 먼저 획득하시기 바랍니다.' },
                        { q: '메일 용량이 꽉 찼는데 보안 점검이 필요한가요?', a: '메일 용량 부족은 IT 지원팀(Helpdesk) 소관이나, 대용량 첨부파일 유출 우려가 있을 경우 보안 교육 대상자가 될 수 있습니다.' },
                        { q: '외부 사이트 접속이 차단되었습니다.', a: '업무상 반드시 필요한 사이트인 경우 [사이트 예외 처리 신청] 프로세스를 통해 보안팀의 승인을 받으셔야 합니다.' }
                    ].map((f, i) => `
                                <div class="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 overflow-hidden">
                                    <button class="faq-btn w-full p-6 text-left flex justify-between items-center group">
                                        <div class="flex items-center gap-4">
                                            <span class="w-8 h-8 rounded-lg bg-gray-50 dark:bg-gray-900 flex items-center justify-center text-xs font-black text-blue-500">Q</span>
                                            <span class="font-bold text-sm dark:text-gray-100 group-hover:text-blue-500 transition-colors">${f.q}</span>
                                        </div>
                                        <i class="fas fa-plus text-xs text-gray-300 group-hover:text-blue-500 transition-all"></i>
                                    </button>
                                    <div class="faq-body max-h-0 overflow-hidden transition-all duration-300 ease-in-out bg-gray-50 dark:bg-gray-900/50">
                                        <div class="p-6 pt-0 ml-12 text-sm text-gray-500 font-bold leading-relaxed">${f.a}</div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `,
                afterRender: () => {
                    helpers.qsa('.faq-btn').forEach(btn => {
                        btn.onclick = () => {
                            const body = btn.nextElementSibling;
                            const icon = btn.querySelector('i');
                            const isOpen = body.style.maxHeight;
                            body.style.maxHeight = isOpen ? null : body.scrollHeight + 'px';
                            icon.classList.toggle('fa-plus', !!isOpen);
                            icon.classList.toggle('fa-minus', !isOpen);
                        };
                    });
                }
            },
            profile: {
                title: '내 프로필',
                render: () => `
                    <div class="section-animate max-w-5xl mx-auto">
                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <div class="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 p-8 text-center">
                                <div class="relative w-32 h-32 mx-auto mb-6">
                                    <div class="w-full h-full rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-4xl font-black text-[#1e3a8a] dark:text-blue-400">TIS</div>
                                    <div class="absolute bottom-1 right-1 w-8 h-8 bg-green-500 border-4 border-white dark:border-gray-800 rounded-full"></div>
                                </div>
                                <h3 class="text-xl font-black dark:text-gray-100">Portal User</h3>
                                <p class="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-6">Department: Info Security Team</p>
                                <div class="flex justify-center gap-2 mb-8">
                                    <span class="px-3 py-1 bg-yellow-100 text-yellow-700 text-[9px] font-black rounded-full">LEVEL 12</span>
                                    <span class="px-3 py-1 bg-blue-100 text-blue-700 text-[9px] font-black rounded-full">MVP 2025</span>
                                </div>
                                <button class="w-full py-3 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-black hover:bg-gray-50 dark:hover:bg-gray-700 transition">프로필 수정</button>
                            </div>
                            <div class="lg:col-span-2 space-y-6">
                                <div class="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 p-8">
                                    <h4 class="font-black mb-6 flex items-center gap-2"><i class="fas fa-medal text-orange-400"></i> 나의 획득 배지</h4>
                                    <div class="flex flex-wrap gap-4">
                                        ${['Security Pro', 'Always Locked', 'Phishing Hunter', 'Quick Reporter', 'Quiz Master'].map(b => `
                                            <div class="flex flex-col items-center gap-2 w-20">
                                                <div class="w-16 h-16 rounded-2xl bg-gray-50 dark:bg-gray-900 flex items-center justify-center text-2xl shadow-inner border border-gray-100 dark:border-gray-700 grayscale hover:grayscale-0 transition cursor-help" title="${b} 배지">🏅</div>
                                                <span class="text-[9px] font-bold text-gray-400 text-center">${b}</span>
                                            </div>
                                        `).join('')}
                                    </div>
                                </div>
                                <div class="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
                                     <div class="p-6 border-b border-gray-100 dark:border-gray-700">
                                        <h4 class="font-black">최근 활동 내역</h4>
                                     </div>
                                     <div class="divide-y divide-gray-50 dark:divide-gray-700">
                                        ${[
                        { act: '보안 퀴즈 완료', time: '방금 전', point: '+10' },
                        { act: '데일리 체크리스트 수행', time: '2시간 전', point: '+5' },
                        { act: '보안 서약서 제출 성공', time: '어제', point: '+50' }
                    ].map(a => `
                                            <div class="p-4 flex justify-between items-center text-sm">
                                                <div>
                                                    <p class="font-bold dark:text-gray-200">${a.act}</p>
                                                    <p class="text-[10px] text-gray-400 font-bold">${a.time}</p>
                                                </div>
                                                <span class="text-blue-500 font-black">${a.point} pts</span>
                                            </div>
                                        `).join('')}
                                     </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `
            }
        };

        // --- Core Functions ---

        function updateTheme() {
            document.documentElement.classList.toggle('dark', state.isDark);
            storage.set('tis_theme', state.isDark ? 'dark' : 'light');
        }

        function loadSection(id) {
            if (!sections[id]) {
                notifications.show('존재하지 않는 페이지입니다.', 'error');
                return;
            }

            console.log('Routing to:', id);
            state.currentSection = id;

            // Show skeleton loader
            els.dynamicContent.innerHTML = '';
            els.skeleton.classList.remove('hidden');

            // Simulate loading delay for better UX
            setTimeout(() => {
                els.skeleton.classList.add('hidden');
                els.dynamicContent.innerHTML = sections[id].render();
                els.breadcrumb.textContent = sections[id].title;

                // Active link update
                els.navLinks.forEach(link => {
                    link.classList.toggle('active', link.getAttribute('data-section') === id);
                });

                // Post-render initialization
                if (sections[id].afterRender) sections[id].afterRender();

                // Window title
                document.title = `TIS | ${sections[id].title}`;

                if (window.location.hash !== '#' + id) {
                    window.location.hash = id;
                }

                els.dynamicContent.scrollTop = 0;
            }, 300);
        }

        function initSignaturePad() {
            const canvas = helpers.qs('#signature-pad');
            const clearBtn = helpers.qs('#clear-signature');
            if (!canvas) return;

            const ctx = canvas.getContext('2d');
            let painting = false;

            const resize = () => {
                const ratio = Math.max(window.devicePixelRatio || 1, 1);
                canvas.width = canvas.offsetWidth * ratio;
                canvas.height = canvas.offsetHeight * ratio;
                ctx.scale(ratio, ratio);
                ctx.strokeStyle = '#1e3a8a';
                ctx.lineWidth = 2;
                ctx.lineJoin = 'round';
                ctx.lineCap = 'round';
            };

            window.addEventListener('resize', resize);
            resize();

            const getPos = (e) => {
                const rect = canvas.getBoundingClientRect();
                return {
                    x: (e.clientX || (e.touches && e.touches[0].clientX)) - rect.left,
                    y: (e.clientY || (e.touches && e.touches[0].clientY)) - rect.top
                };
            };

            const start = (e) => { painting = true; draw(e); };
            const stop = () => { painting = false; ctx.beginPath(); };
            const draw = (e) => {
                if (!painting) return;
                const pos = getPos(e);
                ctx.lineTo(pos.x, pos.y);
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(pos.x, pos.y);
            };

            helpers.on(canvas, 'mousedown', start);
            helpers.on(canvas, 'mouseup', stop);
            helpers.on(canvas, 'mouseleave', stop);
            helpers.on(canvas, 'mousemove', draw);
            helpers.on(canvas, 'touchstart', (e) => { e.preventDefault(); start(e); });
            helpers.on(canvas, 'touchend', stop);
            helpers.on(canvas, 'touchmove', (e) => { e.preventDefault(); draw(e); });

            if (clearBtn) clearBtn.onclick = () => ctx.clearRect(0, 0, canvas.width, canvas.height);
        }

        // --- Initialization ---

        // Theme Toggle
        els.themeToggle.onclick = () => {
            state.isDark = !state.isDark;
            updateTheme();
            notifications.show(`${state.isDark ? '다크' : '라이트'} 모드로 전환되었습니다.`, 'info');
        };
        updateTheme();

        // Sidebar Toggle
        els.toggleBtn.onclick = () => {
            els.sidebar.classList.toggle('collapsed');
            state.isSidebarCollapsed = els.sidebar.classList.contains('collapsed');
            storage.set('tis_sidebar', state.isSidebarCollapsed ? 'collapsed' : 'expanded');
        };
        if (state.isSidebarCollapsed) els.sidebar.classList.add('collapsed');

        // Nav Click
        els.navLinks.forEach(link => {
            link.onclick = (e) => {
                const id = link.getAttribute('data-section');
                if (id) {
                    e.preventDefault();
                    if (state.currentSection === id) return;
                    loadSection(id);
                }
            };
        });

        // Hash Change
        window.onhashchange = () => {
            const hash = window.location.hash.substring(1);
            if (hash && sections[hash] && state.currentSection !== hash) loadSection(hash);
        };

        // Emergency Banner
        els.closeEmergency.onclick = () => els.emergencyBanner.classList.add('hidden');
        setTimeout(() => els.emergencyBanner.classList.remove('hidden'), 2000);

        // Global Search (Simple implementation)
        els.globalSearch.oninput = (e) => {
            const term = e.target.value.toLowerCase().trim();
            const results = Object.keys(sections).filter(k =>
                sections[k].title.toLowerCase().includes(term) || k.includes(term)
            );
            // This could be expanded to a real search UI
        };

        // Export app instance for global access (e.g. from HTML onclick)
        window.app = { loadSection };

        // Initial Route
        const initial = window.location.hash.substring(1) || 'home';
        loadSection(initial);
    });
})();
